# Stores REST Api

This is built with Flask, Flask-RESTful, Flask-JWT, and Flask-SQLAlchemy.

To get started:

- Create a virtualenv for this project
- Install requirements using `pip install -r requirements.txt`

When you've created the first test, you'll also need to create a correct runtime configuration in PyCharm.

Create a sample unittest configuration, and choose:

- `Path` as target, with your project's `/tests` folder.
